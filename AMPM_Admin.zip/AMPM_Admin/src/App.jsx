import "./App.css";
import Index from "./pages";
import "bootstrap/dist/css/bootstrap.min.css";
function App() {
  return (
    <>
      <Index />
    </>
  );
}

export default App;
