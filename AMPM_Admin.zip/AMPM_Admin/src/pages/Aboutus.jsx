import React from 'react'

function Aboutus() {
  return (
    <div>Aboutus</div>
  )
}

export default Aboutus