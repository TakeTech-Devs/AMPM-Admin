import React from "react";
import { Form, Container, Row, Col, Button } from "react-bootstrap";
import "../styles/Dashboard.scss";
import "../styles/Global.scss";


function Home() {
  return (
    <>
      <div className="cardbox">
        <h3>Banner section</h3>
        <Container>
          <Row>
            <Col lg={4}>
              <Form.Control type="text" placeholder="Normal text" />
            </Col>
            <Col lg={4}>
              <Form.Control type="text" placeholder="Normal text" />
            </Col>
            <Col lg={4}>
              <Form.Control type="text" placeholder="Normal text" />
            </Col>
            <Col lg={4}>
              <Form.Control type="text" placeholder="Normal text" />
            </Col>
            <Col lg={4}>
              <Form.Control type="text" placeholder="Normal text" />
            </Col>
            <Col lg={4}>
              <Form.Control type="text" placeholder="Normal text" />
            </Col>
            <Col xs={12} className=" d-flex justify-content-end gap-2">
              <Button variant="danger">Cancel</Button>
              <Button variant="success">Submit</Button>
            </Col>
          </Row>
        </Container>
      </div>
      <div className="cardbox">
        <h3>Banner bottom cards section</h3>
        <Container>
          <Row>
            <Col lg={4}>
              <Form.Control type="text" placeholder="Normal text" />
            </Col>
            <Col lg={4}>
              <Form.Control type="text" placeholder="Normal text" />
            </Col>
            <Col lg={4}>
              <Form.Control type="text" placeholder="Normal text" />
            </Col>
            <Col lg={4}>
              <Form.Control type="text" placeholder="Normal text" />
            </Col>
            <Col lg={4}>
              <Form.Control type="text" placeholder="Normal text" />
            </Col>
            <Col lg={4}>
              <Form.Control type="text" placeholder="Normal text" />
            </Col>
            <Col xs={12} className=" d-flex justify-content-end gap-2">
              <Button variant="danger">Cancel</Button>
              <Button variant="success">Submit</Button>
            </Col>
          </Row>
        </Container>
      </div>
      <div className="cardbox">
        <h3>Batteries</h3>
        <Container>
          <Row>
            <Col lg={4}>
              <Form.Control type="text" placeholder="Normal text" />
            </Col>
            <Col lg={4}>
              <Form.Control type="text" placeholder="Normal text" />
            </Col>
            <Col lg={4}>
              <Form.Control type="text" placeholder="Normal text" />
            </Col>
            <Col lg={4}>
              <Form.Control type="text" placeholder="Normal text" />
            </Col>
            <Col lg={4}>
              <Form.Control type="text" placeholder="Normal text" />
            </Col>
            <Col lg={4}>
              <Form.Control type="text" placeholder="Normal text" />
            </Col>
          </Row>
        </Container>
      </div>
      <div className="cardbox">
        <h3>What we do</h3>
        <Container>
          <Row>
            <Col lg={4}>
              <Form.Control type="text" placeholder="Normal text" />
            </Col>
            <Col lg={4}>
              <Form.Control type="text" placeholder="Normal text" />
            </Col>
            <Col lg={4}>
              <Form.Control type="text" placeholder="Normal text" />
            </Col>
            <Col lg={4}>
              <Form.Control type="text" placeholder="Normal text" />
            </Col>
            <Col lg={4}>
              <Form.Control type="text" placeholder="Normal text" />
            </Col>
            <Col lg={4}>
              <Form.Control type="text" placeholder="Normal text" />
            </Col>
            <Col xs={12} className=" d-flex justify-content-end gap-2">
              <Button variant="danger">Cancel</Button>
              <Button variant="success">Submit</Button>
            </Col>
          </Row>
        </Container>
      </div>
      <div className="cardbox">
        <h3>Contact US</h3>
        <Container>
          <Row>
            <Col lg={4}>
              <Form.Control type="text" placeholder="Normal text" />
            </Col>
            <Col lg={4}>
              <Form.Control type="text" placeholder="Normal text" />
            </Col>
            <Col lg={4}>
              <Form.Control type="text" placeholder="Normal text" />
            </Col>
            <Col lg={4}>
              <Form.Control type="text" placeholder="Normal text" />
            </Col>
            <Col lg={4}>
              <Form.Control type="text" placeholder="Normal text" />
            </Col>
            <Col lg={4}>
              <Form.Control type="text" placeholder="Normal text" />
            </Col>
            <Col xs={12} className=" d-flex justify-content-end gap-2">
              <Button variant="danger">Cancel</Button>
              <Button variant="success">Submit</Button>
            </Col>
          </Row>
        </Container>
      </div>
    </>
  )
}

export default Home