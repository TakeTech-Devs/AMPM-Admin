import React from "react";
import "../styles/Dashboard.scss";
import "../styles/Global.scss";
import Header from "../components/Header";
import Main from "../components/Main";
import Sidebar from "../components/Sidebar";
function Index() {
  return (
    <>
      <section className="admin">
        <div className="wrapper">
          <Sidebar/>
          <div className="dashboard">
            <Header/>
            <Main/>
          </div>
        </div>
      </section>
    </>
  );
}

export default Index;
