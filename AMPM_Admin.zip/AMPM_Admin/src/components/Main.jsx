import React from "react";
import "../styles/Dashboard.scss";
import "../styles/Global.scss";
import Home from "../pages/Home";

function Main() {
  return (
    <>
      <div className="main">
        <div className="main-page">
          <Home/>
        </div>
      </div>
    </>
  )
}

export default Main